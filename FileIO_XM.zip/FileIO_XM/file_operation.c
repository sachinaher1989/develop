#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>

int main(int argc, char* argv[])
{
	FILE* fd1;
	FILE* fd2;
	FILE* fd3;
	
	FILE** fd;
	char c;
	
	if(argc > 1)
	{
		// printf("argc = %d\n", argc);
		// printf("argv[0] = %s\n", argv[0]);
		// printf("argv[1] = %s\n", argv[1]);
		// printf("argv[2] = %s\n", argv[2]);
		fd = (FILE**)malloc(sizeof(FILE*) * (argc - 1));
		if(fd == NULL)
		{
			printf("Malloc failed\n");
			return -1;
		}
		
		for(int i = 0; i < argc-1; i++)
		{
			fd[i] = fopen(argv[i+1], "r");
			if(fd[i] == NULL)
			{
				printf("Input file is not present or Name is not correct: use name as Input.txt");
				return -1;
			}
		}
	
		fd3 = fopen("./Output.txt", "w+");
		if(fd3 == NULL)
		{
			printf("Output.txt file cannot be created");
			return -1;
		}
	
		for(int i = 0; i < argc-1; i++)
		{
			c = fgetc(fd[i]);
			while(c != EOF)
			{
				fputc(c, fd3);
				c = fgetc(fd[i]);
			}
			fputc('\n', fd3);
		}
		
		for(int i = 0; i < argc-1; i++)
		{
			fclose(fd[i]);
		}
		fclose(fd3);
		free(fd);
		fd = NULL;
	}
	else
	{
		fd1 = fopen("./Input.txt", "r");
		if(fd1 == NULL)
		{
			printf("Input file is not present or Name is not correct: use name as Input.txt");
			return -1;
		}
		
		fd2 = fopen("./Header.txt", "r");
		if(fd2 == NULL)
		{
			printf("Header file is not present or Name is not correct: use name as Header.txt");
			return -1;
		}
		
		fd3 = fopen("./Output.txt", "w+");
		if(fd3 == NULL)
		{
			printf("Output.txt file cannot be created");
			return -1;
		}
		
		c = fgetc(fd1);
		while(c != EOF)
		{
			fputc(c, fd3);
			c = fgetc(fd1);
		}
		
		fputc('\n', fd3);
		
		c = fgetc(fd2);
		while(c != EOF)
		{
			fputc(c, fd3);
			c = fgetc(fd2);
		}
		
		
		fclose(fd1);
		fclose(fd2);
		fclose(fd3);
	
	}
	return 0;
}
